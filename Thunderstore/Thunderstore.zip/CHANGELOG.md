-   **2.0.0**
    -   Added 3 new songs to the boombox item based on the show
        -  Christopher Tyng "Futurama Original Series Mix (C.Tyng Extended Remix)" (Old radio Remix)
        -  The Robot Devil "Robot Hell" (Old radio Remix)
        -  Dr.Zoidberg - "He wants a robot brain" (Old radio Remix)

-   **1.0.0**

    -   Mod released on github.
    -   Bender Life Sized Figurine added as a scrap item for all moons
